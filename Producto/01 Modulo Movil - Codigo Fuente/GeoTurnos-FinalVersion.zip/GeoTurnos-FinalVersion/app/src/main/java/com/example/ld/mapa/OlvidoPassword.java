package com.example.ld.mapa;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

/**
 * Created by ld on 21/10/17.
 */

public class OlvidoPassword extends FragmentActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.olvido_password);

    }

}
